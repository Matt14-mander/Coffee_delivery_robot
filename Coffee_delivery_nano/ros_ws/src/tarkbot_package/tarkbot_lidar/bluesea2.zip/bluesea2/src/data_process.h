#ifndef __DATA_PROC__
#define __DATA_PROC__

bool data_process(sensor_msgs::LaserScan&);

#endif